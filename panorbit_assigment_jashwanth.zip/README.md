The dependencies/requirements to run code

-> nodejs v16 or grater
-> npm v9 or grater

how to run the project

step 1 -> if it is the first time running the project in the current directory open command prompt and enter `npm run dev` this is will install all the neccery packages and will run the project

step 2 -> go to the web browser and enter `http://localhost:300` your good to go
