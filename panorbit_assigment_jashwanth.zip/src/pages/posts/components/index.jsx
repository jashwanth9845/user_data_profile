import React from "react";
import styles from "../css/index.module.css";
export default function Posts() {
  return <div className={styles.container}>Coming Soon...</div>;
}
