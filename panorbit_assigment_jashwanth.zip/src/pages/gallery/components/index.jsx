import React from "react";
import styles from "../css/index.module.css";

export default function Gallery() {
  return <div className={styles.container}>Coming Soon...</div>;
}
